#!/bin/bash
for ((i=1; i < 1000; i++))
do
touch "run-r$i"
done
